<?php

return [


    /**
     * Policy classes
     */
    
    #region Compiler Config
        App\Addon\Panel\AddonPanelPolicy::class,
        App\Panel\AdminPolicy::class,
    #endregion


];
