<?php

use Mmb\Background\Background;

require __DIR__ . '/load.php';










Background::handle();
