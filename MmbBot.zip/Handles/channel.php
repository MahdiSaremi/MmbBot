<?php

return [

    'handlers' => [

        /**
         * Handlers
         */


        #region Compiler Handler

        #endregion
    

        /**
         * Current step handler
         */
        app('step'),



        /**
         * Final handlers
         */

        
        #region Compiler End Handler

        #endregion


    ],

    // 'condition' => function()
    // {
    //     return app('channel_or_create');
    // },

];
