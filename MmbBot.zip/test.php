<?php

use Mmb\Tools\ATool;

require __DIR__ . '/load.php';

print_r(ATool::toArray(mmb()));
