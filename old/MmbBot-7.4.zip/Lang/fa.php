<?php

return [

    'example' => "نمونه", // Use lang('example')

    'access_danied' => "شما به این بخش دسترسی ندارید",

];
