<?php

return [

    'example' => "Example", // Use lang('example')

    'access_danied' => "You do not have access to this section",

];
