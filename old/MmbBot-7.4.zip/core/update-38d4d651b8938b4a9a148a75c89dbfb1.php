
<?php
// Tip: Delete me and run install.php to create new update handler!
require __DIR__ . '/../load.php';

Mmb\Kernel\Kernel::handleUpdate(
    app(Providers\UpdProvider::class)
);
    