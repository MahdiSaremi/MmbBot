<?php

return [

    /**
     * Background handler url
     */
    'url' => config('app.url') . '/background.php',

];
