<?php

return [


    /**
     * Policy classes
     */
    \App\Panel\AdminPolicy::class,


];
