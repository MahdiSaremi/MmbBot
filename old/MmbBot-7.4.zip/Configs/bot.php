<?php

return [

    /**
     * Robot token
     */
    'token' => env('TOKEN', ''),


    /**
     * Username
     */
    'username' => env('USERNAME', ''),

];
