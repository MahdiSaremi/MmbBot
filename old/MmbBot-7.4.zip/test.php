<?php
use Mmb\Controller\Controller;

require __DIR__ . '/load.php';


#[X]
class Test extends Controller
{

    public function hi()
    {
        print("Hi\n");
    }

}

Test::invoke('hi');
