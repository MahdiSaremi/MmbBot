<?php

return [

    'handlers' => [
        
        /**
         * Handlers
         */
        App\BanBlock::instance(),
        App\Home\Start\StartController::startCommand(),
        App\None::callbackQuery(),
        
        
        /**
         * Current step handler
         */
        app('step'),



        /**
         * Final handlers
         */


    ],

    'condition' => function()
    {
        return app('user_or_create');
    },

];
