<?php

return [

    'handlers' => [

        /**
         * Handlers
         */



        /**
         * Current step handler
         */
        app('step'),



        /**
         * Final handlers
         */


    ],

    // 'condition' => function()
    // {
    //     return app('user_or_create');
    // },

];
