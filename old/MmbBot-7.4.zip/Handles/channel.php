<?php

return [

    'handlers' => [

        /**
         * Handlers
         */



        /**
         * Current step handler
         */
        app('step'),



        /**
         * Final handlers
         */


    ],

    // 'condition' => function()
    // {
    //     return app('channel_or_create');
    // },

];
