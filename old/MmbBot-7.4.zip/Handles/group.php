<?php

return [

    'handlers' => [

        /**
         * Handlers
         */



        /**
         * Current step handler
         */
        app('step'),



        /**
         * Final handlers
         */


    ],

    // 'condition' => function()
    // {
    //     return app('group_or_create');
    // },

];
