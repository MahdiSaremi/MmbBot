<?php
#auto-name
namespace Models;

use Mmb\Db\QueryCol;
use Mmb\Db\Table\Table;

class TestModel extends Table
{

    public static function getTable()
    {
        return 'test_models';
    }

    public static function generate(QueryCol $table)
    {
        $table->text('name');
        $table->int('view')->default(0);
    }

}
