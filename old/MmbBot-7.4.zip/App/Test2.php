<?php
#auto-name
namespace App;
use Mmb\Controller\Controller;

class Test2 extends Controller
{

    public function main()
    {
        responceMenu($this->menu, "وارد منو شدید:");
    }

    public function menu()
    {
        return $this->createFixMenu('menu', [

        ]);
    }

    public function create()
    {
        
    }

    public function editTest()
    {
        
    }

    public function list()
    {
        
    }

    public function search()
    {
        
    }

}
