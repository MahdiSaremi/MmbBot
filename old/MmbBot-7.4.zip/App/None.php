<?php
#auto-name
namespace App;
use Mmb\Controller\Controller;
use Mmb\Controller\QueryControl\CallbackControl;
use Mmb\Controller\QueryControl\QueryBooter;

class None extends Controller
{

    use CallbackControl;
    public function bootCallback(QueryBooter $booter)
    {
        $booter->pattern("none")->invoke('none');
    }

    public function none()
    {
        answer();
    }
    
}
