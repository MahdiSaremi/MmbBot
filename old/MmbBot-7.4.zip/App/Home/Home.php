<?php
#auto-name
namespace App\Home;

use App\Panel\Panel;
use Mmb\Controller\Controller;

class Home extends Controller
{

    public function main($message = null)
    {
        responceMenu($this->menu, $message ?: "خوش آمدید");
    }

    public function menu()
    {
        return $this->createFixMenu('menu', [

            [ Panel::keyIfAllowed("پنل مدیریت", 'main') ],

        ]);
    }

    public function return()
    {
        return $this('main', "به منوی اصلی بازگشتید");
    }

}
