<?php
#auto-name
namespace App\Panel;

use App\Home\Home;
use Mmb\Controller\Controller;

class Panel extends Controller
{

    public function main($message = null)
    {
        responceMenu($this->menu, $message ?: "وارد پنل مدیریت شدید:");
    }

    public function menu()
    {
        return $this->createFixMenu('menu', [

            [ static::key("بازگشت", 'back') ],

        ]);
    }

    public function return()
    {
        return $this('main', "به پنل بازگشتید");
    }

    public function back()
    {
        return Home::invoke('main', "از پنل خارج شدید");
    }
    
}
