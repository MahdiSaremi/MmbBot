<?php
#auto-name
namespace App;
use Mmb\Controller\Handler\Handler;
use Models\User;

class BanBlock extends Handler
{

    public function handle()
    {
        if(User::$this && User::$this->ban && !User::$this->role->ignore_ban)
        {
            $this->stop();
        }
    }
    
}
