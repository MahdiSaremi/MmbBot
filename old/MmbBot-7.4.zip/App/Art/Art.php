<?php
#auto-name
namespace App\Art;

use Mmb\Tools\ATool;
use Mmb\Tools\Dev\DevPhp;
use Mmb\Tools\Text;

class Art
{

    public static function getArts()
    {
        return [
            Arts\Manager\ManagerArt::class,
        ];
    }
    
    public static function art()
    {
        $arts = static::getArts();
        echo "\n>  Select Art type:\n\n";
        foreach($arts as $i => $art)
        {
            echo $i . " - " . $art::getName() . "\n";
            echo join("\n", array_map(function($value) {
                return '  - ' . $value;
            }, $art::getDescription()));
            echo "\n\n";
        }
        echo "\n";

        do
        {
            $index = static::input();
        }
        while(!isset($arts[$index]));

        $name = static::input("Enter name:");

        $class = $arts[$index];
        static::addArt('main', new $class(Text::beforeLast($name, "\\") ?: "", Text::afterLast($name, "\\") ?: $name));

        while($art = static::findNext())
        {
            $art->next();
        }

        foreach(static::$arts as $art)
        {
            $art->save();
        }
    }

    public static function input($title = "", $nullToCancel = true)
    {
        if($title)
            echo ">  $title\n";
        echo ">> ";
        $value = readline();
        if($nullToCancel && $value === "")
        {
            echo ">  Canceled";
            exit;
        }

        return $value;
    }

    public static function findNext()
    {
        foreach(static::$arts as $art)
        {
            if(!$art->stop)
            {
                return $art;
            }
        }
        return false;
    }


    public static $arts = [];
    public static function addArt($name, Art $art)
    {
        static::$arts[$name] = $art;
    }
    public static function addArtToFirst($name, Art $art)
    {
        ATool::insert(static::$arts, 0, $art);
    }
    public static function existsArt($name)
    {
        return isset(static::$arts[$name]);
    }
    public static function getArt($name)
    {
        return static::$arts[$name] ?? null;
    }








    public $php;
    public $namespace;
    public $name;
    public $stop = false;
    public function __construct($namespace, $name)
    {
        $this->php = new DevPhp(null);
        $this->namespace = $namespace;
        $this->name = $name;
        $this->start();
    }

    public static function default()
    {
    }

    public static function getName()
    {
        return 'NO-TITLE';
    }
    public static function getDescription()
    {
        return [];
    }

    public function start()
    {
    }

    public function next()
    {
        
    }

    public function stop()
    {
        $this->stop = true;
    }


    public function inputMethod(array $methods)
    {
        echo "\nSelect attribute:\n\n";
        foreach($methods as $name => $des)
        {
            echo "- $name" . str_repeat(" ", 15 - strlen($name)) . $des . "\n";
        }
        echo "\n";
        $value = $this->input("Select:", false);
        if($value === "")
        {
            $this->stop();
            return;
        }

        $args = explode(":", $value);
        $method = $args[0];
        unset($args[0]);

        if(isset($methods[$method]))
        {
            $this->$method(...$args);
        }
    }

    public function save()
    {
    }

}
