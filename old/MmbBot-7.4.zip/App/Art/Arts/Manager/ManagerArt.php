<?php
#auto-name
namespace App\Art\Arts\Manager;

use App\Art\Art;
use App\Art\Arts\Model\ModelArt;

class ManagerArt extends Art
{

    public static function getName()
    {
        return 'Manager';
    }
    public static function getDescription()
    {
        return [
            "Make model and controllers, forms, and ..."
        ];
    }

    public function start()
    {
        $this->php->class($this->name);
        $model = $this->input("Enter model name:");
        $this->addArtToFirst('model', new ModelArt("", $model));
    }

    public function next()
    {
        $this->inputMethod([
        ]);
    }
    
    public function save()
    {
        $this->php->use("Mmb\Controller\Controller");
        $this->php->extends("Controller");
        
        $this->php->setPath("App/" . $this->namespace . "/" . $this->name . ".php");
        $this->php->namespace(trim("App\\" . str_replace('/', '\\', $this->namespace), "\\"));
        $this->php->save();
    }
    
}
