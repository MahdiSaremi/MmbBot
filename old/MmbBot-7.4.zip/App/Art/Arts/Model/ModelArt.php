<?php
#auto-name
namespace App\Art\Arts\Model;
use App\Art\Art;
use Mmb\Tools\Text;

class ModelArt extends Art
{

    public $mains = [];
    public $stats = [];
    public $autos = [];
    
    public function start()
    {
        $this->php->class($this->name);
    }

    public function next()
    {
        echo "\n\n";
        echo "-----------------------------\n";
        echo "-       Model  Status       -\n";
        echo "-----------------------------\n";
        foreach($this->mains + $this->stats + $this->autos as $column)
        {
            echo "+ $column[0] : $column[1]";
            if(isset($column[2]))
                echo " = $column[2]";
            echo "\n";
        }

        $this->inputMethod([
            'main' => "Add main column: main:name:text",
            'stat' => "Add stat column: stat:view:int:0",
            'auto' => "Add auto fill column: auto:code:text",
            'remove' => "Remove column: remove:name",
        ]);
    }

    public function main($name, $type)
    {
        $this->remove($name);
        $this->mains[$name] = [ $name, $type ];
        echo ">  Column set!\n";
    }
    public function stat($name, $type, $default = null)
    {
        $this->remove($name);
        $this->stats[$name] = [ $name, $type, $default ];
        echo ">  Column set!\n";
    }
    public function auto($name, $type)
    {
        $this->remove($name);
        $this->autos[$name] = [ $name, $type ];
        echo ">  Column set!\n";
    }
    public function remove($name)
    {
        $isset = isset($this->mains[$name])
              || isset($this->stats[$name])
              || isset($this->autos[$name]);
        unset($this->mains[$name]);
        unset($this->stats[$name]);
        unset($this->autos[$name]);
        if($isset)
            echo ">  Old column removed\n";
    }

    public function save()
    {
        $this->php->use("Mmb\Db\Table\Table");
        $this->php->use("Mmb\Db\QueryCol");
        $this->php->extends("Table");

        $this->php->staticMethod('getTable', [], "return '".Text::snake($this->name)."s';");

        $t = "    ";
        $res = "";
        foreach($this->mains as $column)
        {
            $res .= "\n$t$t" . '$table->' . $column[1] . "('{$column[0]}');";
        }
        foreach($this->stats as $column)
        {
            $res .= "\n$t$t" . '$table->' . $column[1] . "('{$column[0]}')";
            if(eqi($column[2], "null"))
                $res .= "->nullable()";
            if($column[2] !== null)
                $res .= "->default({$column[2]})";
            $res .= ";";
        }
        foreach($this->autos as $column)
        {
            $res .= "\n$t$t" . '$table->' . $column[1] . "('{$column[0]}');";
        }
        $this->php->staticMethod('generate', ['QueryCol $table'], trim($res));

        $this->php->setPath("Models/" . $this->name . ".php");
        $this->php->namespace("Models");
        $this->php->save();
    }
    
}
