<?php

use App\Art\Art;

include __DIR__ . '/load.php';

Art::art();
